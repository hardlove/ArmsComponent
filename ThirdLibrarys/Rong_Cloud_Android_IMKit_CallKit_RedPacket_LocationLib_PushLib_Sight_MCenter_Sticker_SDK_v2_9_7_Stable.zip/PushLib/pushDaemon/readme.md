##如何使用
1. 从libs下拷贝需要支持的平台的so文件到app module的libs目录
2. 从executable目录拷贝需要支持的平台的可执行文件到app module的assets目录, 强烈建议拷贝全部可执行文件。
3. 根据您的需求, 参考 http://www.rongcloud.cn/docs/android_push.html#third-party_push 集成第三方推送, 将本目录下的小米 jar 包和华为 aar 包集成到项目中。
